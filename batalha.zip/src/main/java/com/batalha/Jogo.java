package com.batalha;

import java.util.List;

public class Jogo {

    private Jogador mago = new Jogador(Classe.MAGO);
    private Jogador guerreiro = new Jogador(Classe.GUERREIRO);

    public List<Jogador> getJogadores(){
        return List.of(mago, guerreiro);
    }

}
