package com.batalha;

import java.util.Random;

public class Jogador {

    private String nome;
    private int xp;
    private int hp;
    private boolean envenenado;
    private Classe classe;
    private boolean antidoto;

    public Jogador(){

    }

    public Jogador(String nome){
        this.nome = nome;
    }

    public Jogador(Classe classe){
        this.classe = classe;
    }

    public void receberDano(int pontos){
        hp -= pontos;
    }

    public void receberCura(int pontos){
        hp += pontos;
    }

    public void ganharExperiencia(int pontos){
        xp += pontos;
    }

    public void receberAntidoto(){
        envenenado = !envenenado;
    }

    public void atacar(Jogador adversario){
        adversario.receberDano(this.xp);
        ganharExperiencia(1);
    }

    public void curar(Jogador aliado){
        aliado.receberCura(5);
        droparItem();
    }

    private void droparItem() {
        if(new Random().nextInt(100) < 10) {
            antidoto = true;
        }
    }

    public void darAntidoto(Jogador aliado){
        if (temAntidoto()){
            aliado.receberAntidoto();
            antidoto = false;
        }
    }

    public boolean temAntidoto(){
        return antidoto;
    }

    public void guardarAntidoto( ){
        this.antidoto = true;
    }


    public String getNome(){
        return nome;
    }

    public int getXp() {
        return xp;
    }

    public int getHp() {
        return hp;
    }

    public boolean isEnvenenado() {
        return envenenado;
    }

    public String getClasse() {
        return classe;
    }

    public void setClasse(String classe) {
        this.classe = classe;
    }
}
