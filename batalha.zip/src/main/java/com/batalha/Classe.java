package com.batalha;

public enum Classe {
    MAGO,
    GUERREIRO
}
